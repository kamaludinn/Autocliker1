package com.example.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AutoClickService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var isClicking = false

    // Koordinat tombol "Cash Out" (atur manual berdasarkan posisi layar HP kamu)
    private val clickX = 500f
    private val clickY = 1200f

    private val clickIntervalMillis = 8000L // 8 detik

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onServiceConnected() {
        super.onServiceConnected()
        startClicking()
    }

    private fun startClicking() {
        if (isClicking) return
        isClicking = true
        handler.post(clickRunnable)
    }

    private fun stopClicking() {
        isClicking = false
        handler.removeCallbacks(clickRunnable)
    }

    private val clickRunnable = object : Runnable {
        override fun run() {
            performClick(clickX, clickY)
            if (isClicking) {
                handler.postDelayed(this, clickIntervalMillis)
            }
        }
    }

    private fun performClick(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .build()
        dispatchGesture(gesture, null, null)
    }
}